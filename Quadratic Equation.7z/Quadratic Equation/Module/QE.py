import math
import cmath as cm

def equation(a,b,c):
    def D():
        return b ** 2 - 4 * a * c
    if D() < 0:
        def x_1():
            return (-b + cm.sqrt(D()))/(2*a)
        def x_2():
            return (-b - cm.sqrt(D()))/(2*a)
        print(f"D = {D()}")
        print(f"x_1 = {x_1()}")
        print(f"x_2 = {x_2()}")
    if D() == 0:
        def x():
            return (-b + cm.sqrt(D()))/(2*a)
        print(f"D = {D()}")    
        print(f"x = {x()}")
    if D() > 0:
        def x_1():
            return (-b + cm.sqrt(D()))/(2*a)
        def x_2():
            return (-b - cm.sqrt(D()))/(2*a)
        print(f"D = {D()}")
        print(f"x_1 = {x_1()}")
        print(f"x_2 = {x_2()}")