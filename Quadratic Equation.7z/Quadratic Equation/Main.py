from Module import QE
import shutil

width = shutil.get_terminal_size().columns

print("=" * width)
print("[KALKULATOR AKAR-AKAR PERSAMAAN KUADRAT]".center(width))
print("-- By Kristiano --".center(width))
print("=" * width)

print("ax² + bx + c = 0".center(width))

while True:
    a = float(input("Masukan Nilai a (Koefisien x²) = "))
    b = float(input("Masukan Nilai b (Koefisien x) = "))
    c = float(input("Masukan Nilai c (Konstanta) = "))
    print("-" * width)
    print("hasil:")
    QE.equation(a,b,c)
    print("-" * width)
    while True:
        break_or_continue = input("Keluar? (y/n): ").strip().lower()
        if break_or_continue == "y":
            exit()
        elif break_or_continue == "n":
            break
        else:
            print("Pilihan tidak valid! Harap masukkan 'y' atau 'n'.")        